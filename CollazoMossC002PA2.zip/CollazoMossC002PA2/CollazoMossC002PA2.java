
/**
 * @(#) CollazoMossC002PA1.java
 * @author Cameron Moss & Nicholas Collazo
 * @version 1.00 2023/04/03 12:12pm
 * 
 * PROGRAM PURPOSE: to correctly create address books upon users demands
 */


//import scanner for keyboard inputs
import java.util.Scanner;

public class CollazoMossC002PA2 { //this encompasses the whole program
  
  // KEYBOARD scanner
  static Scanner input = new Scanner(System.in);
  
  // int variables to put user data in correct places
  static int bookType = 0;
  
  // string builder to format phone number
  static StringBuilder phoneFormatted;
  
  // family and friend strings formatted for address book titles
  static String family = String.format("%nFAMILY%n%n");
  static String friends = String.format("%nFRIENDS%n%n");
  
  // string variables to hold user's inputted data
  static String addressee = " ", street = " ", cityStateZip = " ", addressBook = "", work = "";
  
  // char variables used in sentinel-controlled loops
  static char correct = ' ';
  
  
  // boolean variables used in sentinel-controlled loops
  static boolean validateInteger = false;
  
  // method to collect data to add to the user's address books
  public static void main(String[] args) {  //this is the main function that holds all code outside of the varis
    
    char another = ' ', anotherAddress = ' ';
    
    System.out.printf("%nBegin entering addresses? \'Y\' or \'N\': ");
    another = input.nextLine().charAt(0);
    
    if (another != 'Y' && another != 'y') {
      System.out.printf("%nExiting program.%n");
      System.exit(0);
    }
    
    while (another == 'Y' || another == 'y') {
      setAddressBook(); // collects address book name
      setOwner(); // collects owner's name
      
      do {
        setAddressee(); //calls setAddressee prompt
        setStreet(); //calls setStreet prompt
        setCityStateZip(); //calls setCityStateZip prompt
        setPhone(); //calls setPhone prompt
        setRelationship(); //calls setRelationship prompt
        
        System.out.printf("%nDo you want to enter another address? \'Y\' or \'N\': ");
        anotherAddress = input.nextLine().charAt(0);
        
      } while (anotherAddress == 'Y' || anotherAddress == 'y'); // end do while loop for address book creation
      printAddressBook(); //calls printAddressBook prompt
      
      System.out.printf("%nDo you want to create another address book? \'Y\' or \'N\': ");
      another = input.nextLine().charAt(0);
      
    }
    input.close();
    System.out.printf("Exiting progam.");
    System.exit(0);
  } // end main method
  
  public static void setAddressBook() {
    do // do while loop for address book type
    {
      System.out.printf("%nAddress Book Type:%n%n"
                          + "1. Personal %n2. Business %n%n"
                          + "Choose from above the address book type: ");
      
      bookType = validateInteger();
      input.nextLine();
      
      switch (bookType) {
        case (1):
          System.out.printf("%nYou entered 1 for Personal. Is this correct?" +
                            " \'Y\' or \'N\': ");
          correct = input.nextLine().charAt(0);
          break;
        case (2):
          System.out.printf("%nYou entered 2 for Business. Is this correct?" +
                            " \'Y\' or \'N\': ");
          correct = input.nextLine().charAt(0);
          break;
        default:
          System.out.printf("%nYou entered %d which is the wrong address book type." +
                            " Try again.%n", bookType);
          correct = 'N';
      }// end switch for booktype
      
    } while (correct != 'Y' && correct != 'y'); // end do while for book type
    
  } // end setAddressBook method
  
  public static void setOwner() {
    String ownerAddrBk = "";
    
    do // do while loop for users name
    {
      addressBook = "";
      System.out.printf("%nEnter your name: ");
      ownerAddrBk = input.nextLine();
      
      System.out.printf("%nYou entered %s. Is this correct? \'Y\' or \'N\': ", ownerAddrBk);
      correct = input.nextLine().charAt(0);
    } while (correct != 'Y' && correct != 'y'); // end do while for users name
    
    addressBook += String.format("%n%S%n%n", ownerAddrBk);
    
  } // end set owner method
  
  public static void setAddressee() {
    do // do while loop for name of addressee
    {
      System.out.printf("%nEnter the name of the addressee: ");
      addressee = input.nextLine();
      
      System.out.printf("%nYou entered %s. Is this correct? \'Y\' or \'N\': ", addressee);
      correct = input.nextLine().charAt(0);
    } while (correct != 'Y' && correct != 'y'); // end do while for name of addressee
    
  } // end method setAddressee
  
  public static void setStreet() {
    do // do while loop street of the addressee
    {
      System.out.printf("%nEnter the street name for addressee: ");
      street = input.nextLine();
      
      System.out.printf("%nYou entered %s. Is this correct? \'Y\' or \'N\': ", street);
      correct = input.nextLine().charAt(0);
    } while (correct != 'Y' && correct != 'y'); // end do while for street
    
  } // end method setStreet
  
  public static void setCityStateZip() {
    do // do while loop for city, state, and zip
    {
      System.out.printf("%nEnter the city, state, and zip code for %s in the correct format: ", addressee);
      cityStateZip = input.nextLine();
      
      System.out.printf("%nYou entered %s. Is this correct? \'Y\' or \'N\': ", cityStateZip);
      correct = input.nextLine().charAt(0);
    } while (correct != 'Y' && correct != 'y'); // end do while for city,state,zip
    
  } // end setCityStateZip method
  
  public static void setPhone() {
    String phone = "";
    do // do while loop for phone #
    {
      System.out.printf("%nEnter the the 10 digit phone number for %s, with no dashes or parentheses: ",
                        addressee);
      phone = input.nextLine();
      
      phoneFormatted = new StringBuilder(phone);
      phoneFormatted.insert(3, '-');
      phoneFormatted.insert(7, '-');
      
      System.out.printf("%nYou entered %s. Is this correct? \'Y\' or \'N\': ", phoneFormatted);
      correct = input.nextLine().charAt(0);
    } while (correct != 'Y' && correct != 'y');// end do while for phone
    
  } // end setPhone method
  
  public static void setRelationship() {
    int relationship = 0;
    do // do while loop for relationship
    {
      System.out.printf("%nRelationship of the addresse:%n%n"
                          + "1. Family %n2. Friends %n3. Work %n%n"
                          + "Choose from above: ");
      
      relationship = validateInteger();
      input.nextLine();
      
      switch (relationship) {
        case (1):
        case (2):
          System.out.printf("%nYou entered %d for %s. Is this correct?" +
                            " \'Y\' or \'N\': ", relationship,
                            relationship == 1 ? "Family" : "Friends");
        correct = input.nextLine().charAt(0);
        break;
        case (3):
          System.out.printf("%nYou entered 3 for Work. Is this correct? " +
                            "\'Y\' or \'N\': ");
          correct = input.nextLine().charAt(0);
          break;
        default:
          System.out.printf("%nYou entered %d which is incorrect." +
                            " Try again.%n", relationship);
          correct = 'N';
      }// end switch for relationship
      
    } while (correct != 'Y' && correct != 'y');// end do while for relationship
    
    switch (relationship) {
      case 1:
        family += formatAddressee();
        break;
      case 2:
        friends += formatAddressee();
        break;
      case 3:
        work += formatAddressee();
        break;
    } // end switch for formatting user data correctly
    
  } // end setRelationship method
  
  public static String formatAddressee() {
    
    return String.format(
                         "Addressee: %s%n" +
                         "Street: %s%n" +
                         "City, State Zip: %s%n" +
                         "Phone: %s%n%n",
                         addressee, street, cityStateZip, phoneFormatted);
    
  } // end formatAddressee method
  
  public static void printAddressBook() {
    switch (bookType) {
      case (1):
        addressBook += family;
        addressBook += friends;
        break;
      case (2):
        addressBook += work;
        break;
        
    } /// end print address book method
    System.out.printf(addressBook);
  }
  
  public static int validateInteger() {
    int num = 0;
    boolean validateInteger = false;
    
    while (!validateInteger) {
      if (input.hasNextInt()) {
        validateInteger = true;
        num = input.nextInt();
      } else {
        System.out.printf("%nNot an integer! " +
                          "Enter a valid integer: ");
        input.next();
      }
    }
    return num;
  }// end validateInteger method
  
} // end class MossC002PA1

/**
 * 
 *  Begin entering addresses? 'Y' or 'N': n
 * 
 Exiting program.
 
 Begin entering addresses? 'Y' or 'N': y
 
 Address Book Type:
 
 1. Personal
 2. Business
 
 Choose from above the address book type:3 
 
 
 You entered 3 which is the wrong address book type. Try again.
 
 Address Book Type:
 
 1. Personal
 2. Business
 
 Choose from above the address book type: l
 
 Not an integer! Enter a valid integer: 1
 
 You entered 1 for Personal. Is this correct? 'Y' or 'N': y
 
 Enter your name: James Kork
 
 You entered James Kork. Is this correct? 'Y' or 'N': n
 
 Enter your name: James Kirk
 
 You entered James Kirk. Is this correct? 'Y' or 'N': y
 
 Enter the name of the addressee: Jorge Kirk
 
 You entered Jorge Kirk. Is this correct? 'Y' or 'N': n
 
 Enter the name of the addressee: George Kirk
 
 You entered George Kirk. Is this correct? 'Y' or 'N': y
 
 Enter the street name for addressee: 123 Main
 
 You entered 123 Main. Is this correct? 'Y' or 'N': n
 
 Enter the street name for addressee: 718 Enterprise Cir
 
 You entered 718 Enterprise Cir. Is this correct? 'Y' or 'N': y
 
 Enter the city, state, and zip code for George Kirk in the correct format: Riveride, CA
 
 You entered Riveride, CA. Is this correct? 'Y' or 'N': n
 
 Enter the city, state, and zip code for George Kirk in the correct format: Riverside, IA 52327
 
 You entered Riverside, IA 52327. Is this correct? 'Y' or 'N': y
 
 Enter the the 10 digit phone number for George Kirk, with no dashes or parentheses: 7197890123
 
 You entered 719-789-0123. Is this correct? 'Y' or 'N': n
 
 Enter the the 10 digit phone number for George Kirk, with no dashes or parentheses: 3197890123
 
 You entered 319-789-0123. Is this correct? 'Y' or 'N': y
 
 Relationship of the addresse:
 
 1. Family
 2. Friends
 3. Work
 
 Choose from above: 4
 
 You entered 4 which is incorrect. Try again.
 
 Relationship of the addresse:
 
 1. Family
 2. Friends
 3. Work
 
 Choose from above: 2
 
 You entered 2 for Friends. Is this correct? 'Y' or 'N': n
 
 Relationship of the addresse:
 
 1. Family
 2. Friends
 3. Work
 
 Choose from above: 1
 
 You entered 1 for Family. Is this correct? 'Y' or 'N': y
 
 Do you want to enter another address? 'Y' or 'N': y
 
 Enter the name of the addressee: Spock
 
 You entered Spock. Is this correct? 'Y' or 'N': y
 
 Enter the street name for addressee: 15 Triple Moon
 
 You entered 15 Triple Moon. Is this correct? 'Y' or 'N': y
 
 Enter the city, state, and zip code for Spock in the correct format: Surak, Vulcan
 
 You entered Surak, Vulcan. Is this correct? 'Y' or 'N': y
 
 Enter the the 10 digit phone number for Spock, with no dashes or parentheses: 4151234567
 
 You entered 415-123-4567. Is this correct? 'Y' or 'N': y
 
 Relationship of the addresse:
 
 1. Family
 2. Friends
 3. Work
 
 Choose from above: 2
 
 You entered 2 for Friends. Is this correct? 'Y' or 'N': y
 
 Do you want to enter another address? 'Y' or 'N': n
 
 JAMES KIRK
 
 
 FAMILY
 
 Addressee: George Kirk
 Street: 718 Enterprise Cir
 City, State Zip: Riverside, IA 52327
 Phone: 319-789-0123
 
 
 FRIENDS
 
 Addressee: Spock
 Street: 15 Triple Moon
 City, State Zip: Surak, Vulcan
 Phone: 415-123-4567
 
 
 Do you want to create another address book? 'Y' or 'N': y
 
 Address Book Type:
 
 1. Personal
 2. Business
 
 Choose from above the address book type: 2
 
 You entered 2 for Business. Is this correct? 'Y' or 'N': y
 
 Enter your name: James Kirk
 
 You entered James Kirk. Is this correct? 'Y' or 'N': y
 
 Enter the name of the addressee: Star Fleet Command
 
 You entered Star Fleet Command. Is this correct? 'Y' or 'N': y
 
 Enter the street name for addressee: 1 Star Fleet
 
 You entered 1 Star Fleet. Is this correct? 'Y' or 'N': y
 
 Enter the city, state, and zip code for Star Fleet Command in the correct format: Fort Baker, CA 98210
 
 You entered Fort Baker, CA 98210. Is this correct? 'Y' or 'N': y
 
 Enter the the 10 digit phone number for Star Fleet Command, with no dashes or parentheses: 4158921519
 
 You entered 415-892-1519. Is this correct? 'Y' or 'N': y
 
 Relationship of the addresse:
 
 1. Family
 2. Friends
 3. Work
 
 Choose from above: 3
 
 You entered 3 for Work. Is this correct? 'Y' or 'N': y
 
 Do you want to enter another address? 'Y' or 'N': y
 
 Enter the name of the addressee: Lt. Commander Montgomery Scott
 
 You entered Lt. Commander Montgomery Scott. Is this correct? 'Y' or 'N': y   
 
 Enter the street name for addressee: 5 Star Fleet #62
 
 You entered 5 Star Fleet #62. Is this correct? 'Y' or 'N': y
 
 Enter the city, state, and zip code for Lt. Commander Montgomery Scott in the correct format: Fort Baker, CA 98210
 
 You entered Fort Baker, CA 98210. Is this correct? 'Y' or 'N': y
 
 Enter the the 10 digit phone number for Lt. Commander Montgomery Scott, with no dashes or parentheses: 4152345678
 
 You entered 415-234-5678. Is this correct? 'Y' or 'N': y
 
 Relationship of the addresse:
 
 1. Family
 2. Friends
 3. Work
 
 Choose from above: 3
 
 You entered 3 for Work. Is this correct? 'Y' or 'N': y
 
 Do you want to enter another address? 'Y' or 'N': n
 
 JAMES KIRK
 
 Addressee: Star Fleet Command
 Street: 1 Star Fleet
 City, State Zip: Fort Baker, CA 98210
 Phone: 415-892-1519
 
 Addressee: Lt. Commander Montgomery Scott
 Street: 5 Star Fleet #62
 City, State Zip: Fort Baker, CA 98210
 Phone: 415-234-5678
 
 
 Do you want to create another address book? 'Y' or 'N': n
 * 
 */